"""
Programs Router
Endpoints for program generation and status checking
"""
from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from uuid import UUID
import os
from pathlib import Path

from ..models.requests import ProgramGenerationRequest, ProgramUpdateRequest
from ..models.responses import (
    JobResponse,
    JobStatusResponse,
    ProgramResponse,
    ProgramListResponse,
    ProgramSummary,
    UpdateStatusResponse
)
from ..services.program_generator_v2 import generate_program_background  # V2: Structured outputs
from ..services.program_updater import (
    update_program_background,
    validate_program_change_with_llm,
    _get_current_program_as_json
)
from ..services.job_manager import create_job, get_job_status
from db.database import get_db
from db.models import UserGeneratedProgram, User
from db.program_utils import get_program_summary_list

router = APIRouter()


def _get_program_file_path(user_id: str, program_id: str, extension: str) -> Path:
    """Get the path to a program file (PDF or markdown)"""
    programs_dir = Path("programs")
    filename = f"program_{user_id}_{program_id}.{extension}"
    return programs_dir / filename


def _get_program_file_urls(user_id: str, program_id: str) -> tuple[str | None, str | None]:
    """
    Get URLs for program PDF and markdown files if they exist.

    Returns:
        (pdf_url, markdown_url) tuple where URLs are None if files don't exist
    """
    pdf_path = _get_program_file_path(user_id, program_id, "pdf")
    md_path = _get_program_file_path(user_id, program_id, "md")

    pdf_url = f"/api/programs/{program_id}/download/pdf" if pdf_path.exists() else None
    md_url = f"/api/programs/{program_id}/download/markdown" if md_path.exists() else None

    return pdf_url, md_url


@router.post("/check-eligibility")
async def check_program_eligibility(
    request: dict,
    db: Session = Depends(get_db)
):
    """
    Check if an email address is eligible to generate a new program.
    Used by website frontend before starting the voice conversation.

    Returns:
        200 OK with eligibility info if allowed
        429 Too Many Requests if rate limited
    """
    from datetime import datetime, timedelta

    email = request.get("email")
    if not email:
        raise HTTPException(status_code=400, detail="Email is required")

    # Find user by email
    user = db.query(User).filter(User.email == email).first()

    if not user:
        # New user - always eligible
        return {
            "eligible": True,
            "message": "Welcome! You're eligible to generate your first program."
        }

    # Check if user has generated a program in the last 7 days
    one_week_ago = datetime.utcnow() - timedelta(days=7)
    recent_program = db.query(UserGeneratedProgram).filter(
        UserGeneratedProgram.user_id == user.id,
        UserGeneratedProgram.created_at >= one_week_ago
    ).order_by(UserGeneratedProgram.created_at.desc()).first()

    if recent_program:
        # Calculate when they can generate next
        next_allowed = recent_program.created_at + timedelta(days=7)
        time_remaining = next_allowed - datetime.utcnow()
        days_remaining = time_remaining.days
        hours_remaining = (time_remaining.seconds // 3600)

        raise HTTPException(
            status_code=429,
            detail=f"You can only generate one program per week. Please try again in {days_remaining} days and {hours_remaining} hours."
        )

    # Eligible to generate
    return {
        "eligible": True,
        "message": "You're eligible to generate a new program!"
    }


@router.post("/generate", response_model=JobResponse, status_code=202)
async def start_program_generation(
    request: ProgramGenerationRequest,
    db: Session = Depends(get_db)
):
    """
    Start generating a workout program via Celery.
    Returns immediately with a job_id to track progress.

    Returns:
        202 Accepted with job information
    """
    from datetime import datetime, timedelta
    from ..celery_tasks import generate_program_task

    # Get or create user
    user = db.query(User).filter(User.id == request.user_id).first()
    if not user:
        # Create new user with the provided information
        user = User(
            id=request.user_id,
            email=request.email,
            name=request.name
        )
        db.add(user)
        db.commit()
        db.refresh(user)
        print(f"[API] Created new user {user.id} ({user.email}) for program generation")

    # Rate limiting: Check if user has generated a program in the last 7 days
    one_week_ago = datetime.utcnow() - timedelta(days=7)
    recent_program = db.query(UserGeneratedProgram).filter(
        UserGeneratedProgram.user_id == request.user_id,
        UserGeneratedProgram.created_at >= one_week_ago
    ).order_by(UserGeneratedProgram.created_at.desc()).first()

    if recent_program:
        # Calculate when they can generate next
        next_allowed = recent_program.created_at + timedelta(days=7)
        days_remaining = (next_allowed - datetime.utcnow()).days
        hours_remaining = ((next_allowed - datetime.utcnow()).seconds // 3600)

        raise HTTPException(
            status_code=429,
            detail=f"You can only generate one program per week. Please try again in {days_remaining} days and {hours_remaining} hours."
        )

    # Create job record
    job = create_job(
        db=db,
        user_id=str(request.user_id),
        height_cm=request.height_cm,
        weight_kg=request.weight_kg,
        goal_category=request.goal_category,
        goal_raw=request.goal_raw,
        duration_weeks=request.duration_weeks,
        days_per_week=request.days_per_week,
        fitness_level=request.fitness_level,
        age=request.age,
        sex=request.sex,
        session_duration=request.session_duration,
        injury_history=request.injury_history,
        specific_sport=request.specific_sport,
        has_vbt_capability=request.has_vbt_capability,
        user_notes=request.user_notes
    )

    # Dispatch to Celery
    task = generate_program_task.delay(
        job_id=str(job.id),
        user_id=str(request.user_id),
        params={
            "name": user.name,
            "height_cm": request.height_cm,
            "weight_kg": request.weight_kg,
            "goal_category": request.goal_category,
            "goal_raw": request.goal_raw,
            "duration_weeks": request.duration_weeks,
            "days_per_week": request.days_per_week,
            "fitness_level": request.fitness_level,
            "age": request.age,
            "sex": request.sex,
            "session_duration": request.session_duration,
            "injury_history": request.injury_history,
            "specific_sport": request.specific_sport,
            "has_vbt_capability": request.has_vbt_capability,
            "user_notes": request.user_notes,
            "send_email": request.send_email
        }
    )

    print(f"[API] Dispatched Celery task {task.id} for job {job.id} (user: {user.name})")

    return JobResponse(
        job_id=str(job.id),
        status="pending",
        message="Program generation started"
    )


@router.get("/status/{job_id}", response_model=JobStatusResponse)
async def get_generation_status(
    job_id: UUID,
    db: Session = Depends(get_db)
):
    """
    Check the status of a program generation job.

    Args:
        job_id: UUID of the generation job

    Returns:
        Job status information including PDF/markdown download URLs

    Raises:
        404: Job not found
    """
    job = get_job_status(db, str(job_id))

    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    response = JobStatusResponse(
        job_id=str(job.id),
        status=job.status,
        progress=job.progress,
        created_at=job.created_at,
        started_at=job.started_at,
        completed_at=job.completed_at
    )

    if job.status == "completed" and job.program_id:
        response.program_id = str(job.program_id)

        # Get PDF and markdown URLs if files exist
        pdf_url, md_url = _get_program_file_urls(job.user_id, str(job.program_id))
        response.pdf_url = pdf_url
        response.markdown_url = md_url
    elif job.status == "failed":
        response.error_message = job.error_message

    return response


@router.get("/{program_id}", response_model=ProgramResponse)
async def get_program(
    program_id: int,
    db: Session = Depends(get_db)
):
    """
    Retrieve a generated program by ID.

    Args:
        program_id: Integer ID of the program

    Returns:
        Program information including PDF/markdown download URLs

    Raises:
        404: Program not found
    """
    program = db.query(UserGeneratedProgram).filter(
        UserGeneratedProgram.id == program_id
    ).first()

    if not program:
        raise HTTPException(status_code=404, detail="Program not found")

    # Get PDF and markdown URLs if files exist
    pdf_url, md_url = _get_program_file_urls(str(program.user_id), str(program_id))

    return ProgramResponse(
        id=str(program.id),
        name=program.name,
        description=program.description,
        duration_weeks=program.duration_weeks,
        created_at=program.created_at,
        pdf_url=pdf_url,
        markdown_url=md_url
    )


@router.get("/list/{user_id}", response_model=ProgramListResponse)
async def list_user_programs(
    user_id: UUID,
    db: Session = Depends(get_db)
):
    """
    Get a list of all programs for a user.

    Args:
        user_id: UUID of the user

    Returns:
        List of program summaries

    Raises:
        404: User not found
    """
    # Verify user exists
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail=f"User {user_id} not found")

    # Get program summaries
    summaries = get_program_summary_list(db, str(user_id))

    return ProgramListResponse(
        programs=[ProgramSummary(**s) for s in summaries],
        total_count=len(summaries)
    )


@router.post("/{program_id}/update", response_model=JobResponse, status_code=202)
async def start_program_update(
    program_id: int,
    request: ProgramUpdateRequest,
    db: Session = Depends(get_db)
):
    """
    Start updating an existing workout program via Celery.
    Returns immediately with a job_id to track progress.

    Args:
        program_id: ID of the program to update
        request: Update request with change description and user profile

    Returns:
        202 Accepted with job information

    Raises:
        404: Program not found
    """
    from ..celery_tasks import update_program_task

    # Verify program exists and get its user_id
    program = db.query(UserGeneratedProgram).filter(
        UserGeneratedProgram.id == program_id
    ).first()

    if not program:
        raise HTTPException(status_code=404, detail=f"Program {program_id} not found")

    user_id = str(program.user_id)

    # Create job record
    job = create_job(
        db=db,
        user_id=user_id,
        height_cm=request.height_cm,
        weight_kg=request.weight_kg,
        goal_category="update",  # Special marker for update jobs
        goal_raw=request.change_request,
        duration_weeks=program.duration_weeks,  # Current duration
        days_per_week=0,  # Not applicable for updates
        fitness_level=request.fitness_level,
        age=request.age,
        sex=request.sex,
        session_duration=None,
        injury_history=None,
        specific_sport=None,
        has_vbt_capability=False,
        user_notes=f"UPDATE: {request.change_request}"
    )

    # Build user profile for update
    user_profile = {
        "age": request.age,
        "sex": request.sex,
        "height_cm": request.height_cm,
        "weight_kg": request.weight_kg,
        "fitness_level": request.fitness_level
    }

    # Dispatch to Celery
    task = update_program_task.delay(
        job_id=str(job.id),
        user_id=user_id,
        program_id=program_id,
        change_request=request.change_request,
        user_profile=user_profile
    )

    print(f"[API] Dispatched Celery update task {task.id} for program {program_id}")

    return JobResponse(
        job_id=str(job.id),
        status="pending",
        message="Program update started"
    )


@router.get("/update-status/{job_id}", response_model=UpdateStatusResponse)
async def get_update_status(
    job_id: UUID,
    db: Session = Depends(get_db)
):
    """
    Check the status of a program update job.

    Args:
        job_id: UUID of the update job

    Returns:
        Update job status information including diff

    Raises:
        404: Job not found
    """
    job = get_job_status(db, str(job_id))

    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    response = UpdateStatusResponse(
        job_id=str(job.id),
        status=job.status,
        progress=job.progress,
        created_at=job.created_at,
        started_at=job.started_at,
        completed_at=job.completed_at
    )

    if job.status == "completed" and job.program_id:
        response.program_id = str(job.program_id)

        # Extract diff from metadata if available
        if hasattr(job, 'metadata') and job.metadata:
            import json
            try:
                metadata = json.loads(job.metadata) if isinstance(job.metadata, str) else job.metadata
                response.diff = metadata.get("diff", [])
            except:
                pass

    elif job.status == "failed":
        response.error_message = job.error_message

    return response


@router.post("/{program_id}/validate")
async def validate_program_change(
    program_id: int,
    request: ProgramUpdateRequest,
    db: Session = Depends(get_db)
):
    """
    Validate a proposed program change without applying it.
    Returns whether the change is risky and suggests alternatives.

    Args:
        program_id: ID of the program to validate against
        request: Update request with change description and user profile

    Returns:
        Validation result with warning and alternative if risky

    Raises:
        404: Program not found
    """
    # Verify program exists
    program = db.query(UserGeneratedProgram).filter(
        UserGeneratedProgram.id == program_id
    ).first()

    if not program:
        raise HTTPException(status_code=404, detail=f"Program {program_id} not found")

    # Get current program structure
    current_program = _get_current_program_as_json(db, program_id)

    if not current_program:
        raise HTTPException(status_code=500, detail="Failed to load program")

    # Build user profile
    user_profile = {
        "age": request.age,
        "sex": request.sex,
        "height_cm": request.height_cm,
        "weight_kg": request.weight_kg,
        "fitness_level": request.fitness_level
    }

    # Run validation
    validation_result = await validate_program_change_with_llm(
        current_program=current_program,
        change_request=request.change_request,
        user_profile=user_profile
    )

    return validation_result


@router.get("/{program_id}/download/pdf")
async def download_program_pdf(
    program_id: int,
    db: Session = Depends(get_db)
):
    """
    Download the PDF file for a program.

    Args:
        program_id: ID of the program

    Returns:
        PDF file download

    Raises:
        404: Program or PDF file not found
    """
    # Verify program exists
    program = db.query(UserGeneratedProgram).filter(
        UserGeneratedProgram.id == program_id
    ).first()

    if not program:
        raise HTTPException(status_code=404, detail=f"Program {program_id} not found")

    # Get PDF path
    pdf_path = _get_program_file_path(str(program.user_id), str(program_id), "pdf")

    if not pdf_path.exists():
        raise HTTPException(
            status_code=404,
            detail=f"PDF file not found for program {program_id}. It may still be generating."
        )

    # Return file response
    return FileResponse(
        path=str(pdf_path),
        filename=f"{program.name.replace(' ', '_')}.pdf",
        media_type="application/pdf"
    )


@router.get("/{program_id}/download/markdown")
async def download_program_markdown(
    program_id: int,
    db: Session = Depends(get_db)
):
    """
    Download the Markdown file for a program.

    Args:
        program_id: ID of the program

    Returns:
        Markdown file download

    Raises:
        404: Program or markdown file not found
    """
    # Verify program exists
    program = db.query(UserGeneratedProgram).filter(
        UserGeneratedProgram.id == program_id
    ).first()

    if not program:
        raise HTTPException(status_code=404, detail=f"Program {program_id} not found")

    # Get markdown path
    md_path = _get_program_file_path(str(program.user_id), str(program_id), "md")

    if not md_path.exists():
        raise HTTPException(
            status_code=404,
            detail=f"Markdown file not found for program {program_id}. It may still be generating."
        )

    # Return file response
    return FileResponse(
        path=str(md_path),
        filename=f"{program.name.replace(' ', '_')}.md",
        media_type="text/markdown"
    )
